<?php
/**
 * Plugin Name: Sensei Certificates
 * Description: This is an empty mock plugin used in E2E testing.
 * Version: 1.0.0
 * Author: Automattic
 * Author URI: https://automattic.com
 * License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Requires at least: 5.0
 * Tested up to: 5.4
 * Requires PHP: 5.6
 */